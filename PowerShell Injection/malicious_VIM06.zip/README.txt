This is a demonstration ZIP archive for VIM-06 research.
Safe decoy file.
